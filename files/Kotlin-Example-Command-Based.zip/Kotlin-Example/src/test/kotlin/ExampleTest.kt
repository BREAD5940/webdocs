import org.junit.Test

class ExampleTest {

    @Test
    fun exampleTest() {
        println("Hello, world!")
    }
}