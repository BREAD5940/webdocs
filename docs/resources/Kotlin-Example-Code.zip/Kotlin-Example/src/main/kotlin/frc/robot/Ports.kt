package frc.robot

object Ports {

    const val kPCMID = 9

    object DrivePorts {
        val LEFT_PORTS = listOf(1, 2)
        val RIGHT_PORTS = listOf(3, 4)
        val SHIFTER_PORTS = listOf(4, 5)
    }
}