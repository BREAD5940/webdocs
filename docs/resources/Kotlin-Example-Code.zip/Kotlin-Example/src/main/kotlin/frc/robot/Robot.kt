
package frc.robot

import frc.robot.subsystems.drive.DriveSubsystem
import org.ghrobotics.lib.wrappers.FalconTimedRobot

object Robot : FalconTimedRobot() {

    override fun robotInit() {
        Network // at the top because s3ndable choosers need to be instantiated

        +DriveSubsystem
        Controls
        super.robotInit()
    }

    override fun robotPeriodic() {
        Controls.update()
        Network.update()
        super.robotPeriodic()
    }
}

fun main() {
    Robot.start()
}