package frc.robot

import frc.robot.subsystems.drive.DriveSubsystem
import org.ghrobotics.lib.wrappers.hid.*

object Controls {

    var isClimbing = false
        private set

    val driverFalconXbox = xboxController(0) {
        registerEmergencyMode()

        state({ !isClimbing }) {
            // bind buttons here. For example,

            // Shifting
            button(kBumperLeft).changeOn { DriveSubsystem.lowGear = true }.changeOff { DriveSubsystem.lowGear = false }
        }
    }

    fun update() {
        driverFalconXbox.update()
    }
}

private fun FalconXboxBuilder.registerEmergencyMode() {
    button(kBack).changeOn {
        Robot.activateEmergency()
    }
    button(kStart).changeOn {
        Robot.recoverFromEmergency()
    }
}