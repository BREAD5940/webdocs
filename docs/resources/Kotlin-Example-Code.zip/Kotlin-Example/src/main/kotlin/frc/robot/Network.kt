/*
 * FRC Team 5190
 * Green Hope Falcons
 */

package frc.robot

import edu.wpi.first.wpilibj.shuffleboard.BuiltInLayouts
import edu.wpi.first.wpilibj.shuffleboard.Shuffleboard
import edu.wpi.first.wpilibj.shuffleboard.ShuffleboardTab
import frc.robot.auto.Autonomous
import frc.robot.subsystems.drive.DriveSubsystem
import org.ghrobotics.lib.wrappers.networktables.enumSendableChooser

object Network {

    val startingPositionChooser = enumSendableChooser<Autonomous.StartingPositions>()
    val autoModeChooser = enumSendableChooser<Autonomous.Mode>()

    private val mainShuffleboardDisplay: ShuffleboardTab = Shuffleboard.getTab("CROISSANT")

    private val autoLayout = mainShuffleboardDisplay.getLayout("Autonomous", BuiltInLayouts.kList)
            .withSize(2, 2)
            .withPosition(0, 0)

    private val driveLayout = mainShuffleboardDisplay.getLayout("Autonomous", BuiltInLayouts.kList)
            .withSize(2, 2)
            .withPosition(2, 0)

    private val driveAngle = driveLayout.add("Drivetrain", -1000.0).entry

    init {

        startingPositionChooser.setDefaultOption(Autonomous.StartingPositions.CENTER.name, Autonomous.StartingPositions.CENTER)
        autoModeChooser.setDefaultOption(Autonomous.Mode.DO_NOTHING.name, Autonomous.Mode.DO_NOTHING)

        // Put choosers on dashboard
        autoLayout.add(
                "Auto Mode",
                autoModeChooser
        )
        autoLayout.add(
                "Starting Position",
                startingPositionChooser
        )
    }

    fun update() {
        // update your stuff here
        driveAngle.setDouble(DriveSubsystem.robotPosition.rotation.degree)
    }
}