// Implementation from Team 5190 Green Hope Robotics

package frc.robot.auto

import org.ghrobotics.lib.mathematics.twodim.geometry.Pose2d

/**
 * Manages the autonomous mode of the game.
 */
object Autonomous {

    @Suppress("unused")
    enum class StartingPositions(val pose: Pose2d) {
        LEFT(TODO("not implemented")),
        CENTER(TODO("not implemented")),
        RIGHT(TODO("not implemented")),
        LEFT_REVERSED(TODO("not implemented")),
        RIGHT_REVERSED(TODO("not implemented"))
    }

    @Suppress("unused")
    enum class Mode { TEST_TRAJECTORIES, BOTTOM_ROCKET, BOTTOM_ROCKET_2, FORWARD_CARGO_SHIP, SIDE_CARGO_SHIP, HYBRID_LEFT, HYBRID_RIGHT, DO_NOTHING }
}